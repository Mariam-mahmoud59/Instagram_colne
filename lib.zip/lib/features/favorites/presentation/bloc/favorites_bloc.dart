class FavoritesBloc {}
