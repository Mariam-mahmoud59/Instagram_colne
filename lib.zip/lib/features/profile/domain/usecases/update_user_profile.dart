import '../repositories/profile_repository.dart';

class UpdateUserProfile {
  final ProfileRepository repository;
  UpdateUserProfile(this.repository);
  // Add call method or logic as needed
}
