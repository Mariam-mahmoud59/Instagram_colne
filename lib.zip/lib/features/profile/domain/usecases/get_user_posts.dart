import '../repositories/profile_repository.dart';

class GetUserPosts {
  final ProfileRepository repository;
  GetUserPosts(this.repository);
  // Add call method or logic as needed
}
