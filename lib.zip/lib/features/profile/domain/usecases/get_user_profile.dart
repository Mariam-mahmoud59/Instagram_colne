import '../repositories/profile_repository.dart';

class GetUserProfile {
  final ProfileRepository repository;
  GetUserProfile(this.repository);
  // Add call method or logic as needed
}
