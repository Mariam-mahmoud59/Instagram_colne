class CreateStoryItem {}
