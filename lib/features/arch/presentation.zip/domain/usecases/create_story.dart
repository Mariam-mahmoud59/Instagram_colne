import '../repositories/story_repository.dart';

class CreateStory {
  final StoryRepository repository;
  CreateStory(this.repository);
  // Add call method or logic as needed
} 